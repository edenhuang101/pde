# Project Name
PRJ_NAME = 'PDE OAM'

# PATH
OAM_DIR = '/home/docker/oam'
LOG_DIR = '%s/log' % OAM_DIR
DEBUG_DIR = '%s/debug' % OAM_DIR
SQL_DIR = '%s/sql' % OAM_DIR
DATA_DIR = '/home/docker/dev_data/gnuplot'

# logging config file
LOGGING_CONFIG_FILE = '%s/config/logging.conf' % OAM_DIR

# Alarm log path
ALARM_LOG_PATH = "/home/docker/oam/log"

# database configuration settings
database = dict(
    # for Docker
    HOST="172.17.0.2",
    PORT=3306,
    USER="docker",
    PASSWORD="docker",
    DATABASE="dockerdb",
)
