#!/bin/bash
export EDITOR=/usr/local/bin/vim
export OAMHOME=$HOME/oam
export PYTHONPATH=$OAMHOME/lib:$OAMHOME/config
export PATH=$PATH:/usr/local/bin:$OAMHOME/bin
export OAMDBG=$HOME/oam/debug
export OAMLOG=$HOME/oam/log

# Define alias
if [[ -z $TASHOME ]] && [[ -z $TCSHOME ]]; then
    alias cdhome='cd $OAMHOME'
    alias cddbg='cd $OAMDBG'
    alias cdlog='cd $OAMLOG'
    alias cdlib='cd $OAMHOME/lib'
    alias cdbin='cd $OAMHOME/bin'
    alias cdunit='cd $OAMHOME/pyunit'
    alias cdconf='cd $OAMHOME/config'
    alias cdsql='cd $OAMHOME/sql'
    alias viconf='vi $OAMHOME/config/oamconf.py'
    alias grep='grep --color'
    alias egrep='egrep --color'
fi
