#!/bin/bash
export EDITOR=/usr/local/bin/vim
export OAMHOME=$HOME/oam
export PYTHONPATH=$OAMHOME/lib:$OAMHOME/config
export PATH=$PATH:/usr/local/bin:$OAMHOME/bin:$OAMHOME/unit
export OAMDBG=$HOME/oam/debug
export OAMLOG=$HOME/oam/log

# Define alias
if [[ -z $TASHOME ]] && [[ -z $TCSHOME ]]; then
    alias cdhome='cd $OAMHOME'
    alias cddbg='cd $OAMDBG'
    alias cdlog='cd $OAMLOG'
    alias cdlib='cd $OAMHOME/lib'
    alias cdbin='cd $OAMHOME/bin'
    alias cdunit='cd $OAMHOME/pyunit'
    alias cdconf='cd $OAMHOME/config'
    alias cdsql='cd $OAMHOME/sql'
    alias viconf='vi $OAMHOME/config/oamconf.py'
    alias grep='grep --color'
    alias egrep='egrep --color'
    alias catp='pygmentize -g'
fi

# for unit test
export HASCCS=true
export HASSIULOG=false
export HASHA=false
export HASFMS=false
export HASSEPTEL=false
#SCSTYPE null, scsgcc, scssim, scsisup
export SCSTYPE=scsgcc
#MCSTYPE null, mcstdm mcssim
export MCSTYPE=mcstdm
export PSBIN=/bin/ps
export SEPTEL_HOME=$OAMHOME/unit
export SIULOG=$OAMHOME/log

# source oamsrc conf
if [ -f "$OAMHOME/config/oamrtenv.conf" ]; then
    source $OAMHOME/config/oamrtenv.conf
fi
